# AstroRoot — Landing Page

## GitHub Pages-ზე გაშვება (3 ნაბიჯი)

### 1. Repository შექმნა
1. github.com-ზე შედი
2. "+" → "New repository"
3. სახელი: `astroroot` (ან სხვა)
4. **Public** აირჩიე
5. "Create repository"

### 2. ფაილების ატვირთვა
1. Repository-ში: "Add file" → "Upload files"
2. ყველა ფაილი ატვირთე (**სტრუქტურა შეინახე**):
   ```
   index.html
   css/style.css
   js/main.js
   images/logo.png
   ```
3. "Commit changes"

### 3. GitHub Pages ჩართვა
1. Repository → **Settings**
2. მარცხნივ: **Pages**
3. Source: **Deploy from a branch**
4. Branch: **main** → **/ (root)**
5. **Save**

რამდენიმე წუთში საიტი ხელმისაწვდომი იქნება:
**`https://YOUR_USERNAME.github.io/astroroot/`**

---
© 2024 AstroRoot
